import unittest

from vehicle_alert.protocol import TelemetryError, format_location, parse_telemetry


class ProtocolTests(unittest.TestCase):
    def test_parse_valid_gps_line(self):
        data = parse_telemetry(
            '{"vibration":1,"alcohol_raw":220,"gps_valid":true,'
            '"latitude":12.5,"longitude":77.6,"gps_age_ms":800}'
        )
        self.assertEqual(data["vibration"], 1)
        self.assertAlmostEqual(data["latitude"], 12.5)
        self.assertEqual(data["gps_age_ms"], 800)

    def test_parse_without_gps(self):
        data = parse_telemetry(
            '{"vibration":0,"alcohol_raw":200,"gps_valid":false}'
        )
        self.assertFalse(data["gps_valid"])

    def test_reject_invalid_json(self):
        with self.assertRaises(TelemetryError):
            parse_telemetry("not json")

    def test_reject_out_of_range_alcohol(self):
        with self.assertRaises(TelemetryError):
            parse_telemetry(
                '{"vibration":0,"alcohol_raw":1200,"gps_valid":false}'
            )

    def test_reject_invalid_coordinates(self):
        with self.assertRaises(TelemetryError):
            parse_telemetry(
                '{"vibration":0,"alcohol_raw":100,"gps_valid":true,'
                '"latitude":120,"longitude":77}'
            )

    def test_format_location(self):
        text = format_location({
            "gps_valid": True,
            "latitude": 12.5,
            "longitude": 77.6,
            "gps_age_ms": 400,
        })
        self.assertIn("12.500000", text)
        self.assertIn("google.com/maps", text)


if __name__ == "__main__":
    unittest.main()
