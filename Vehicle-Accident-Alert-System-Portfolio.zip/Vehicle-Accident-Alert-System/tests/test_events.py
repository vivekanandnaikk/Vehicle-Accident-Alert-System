import unittest

from vehicle_alert.events import EventDetector


class EventDetectorTests(unittest.TestCase):
    def setUp(self):
        self.detector = EventDetector(
            alcohol_threshold=500,
            vibration_active_level=1,
            cooldown_seconds=30,
        )

    def sample(self, vibration=0, alcohol=200):
        return {
            "vibration": vibration,
            "alcohol_raw": alcohol,
            "gps_valid": False,
        }

    def test_vibration_triggers_on_rising_edge_only(self):
        first = self.detector.evaluate(self.sample(vibration=1), now=100)
        held = self.detector.evaluate(self.sample(vibration=1), now=101)
        self.assertEqual([event.kind for event in first], ["vibration"])
        self.assertEqual(held, [])

    def test_vibration_can_trigger_after_release_and_cooldown(self):
        self.detector.evaluate(self.sample(vibration=1), now=100)
        self.detector.evaluate(self.sample(vibration=0), now=101)
        events = self.detector.evaluate(self.sample(vibration=1), now=131)
        self.assertEqual([event.kind for event in events], ["vibration"])

    def test_alcohol_threshold_alert(self):
        events = self.detector.evaluate(self.sample(alcohol=500), now=100)
        self.assertIn("alcohol", [event.kind for event in events])

    def test_alcohol_cooldown(self):
        self.detector.evaluate(self.sample(alcohol=510), now=100)
        events = self.detector.evaluate(self.sample(alcohol=520), now=110)
        self.assertNotIn("alcohol", [event.kind for event in events])

    def test_inactive_vibration_level_can_be_configured(self):
        detector = EventDetector(
            alcohol_threshold=900,
            vibration_active_level=0,
            cooldown_seconds=10,
        )
        events = detector.evaluate(self.sample(vibration=0), now=10)
        self.assertIn("vibration", [event.kind for event in events])


if __name__ == "__main__":
    unittest.main()
