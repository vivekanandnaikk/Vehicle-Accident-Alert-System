"""Validation and formatting for Arduino JSON-lines telemetry."""

from __future__ import annotations

import json
from typing import Any


class TelemetryError(ValueError):
    """Raised when a serial line does not match the expected schema."""


def parse_telemetry(line: str) -> dict[str, Any]:
    try:
        payload = json.loads(line)
    except json.JSONDecodeError as exc:
        raise TelemetryError("Line is not valid JSON") from exc

    if not isinstance(payload, dict):
        raise TelemetryError("Telemetry must be a JSON object")

    if "vibration" not in payload or "alcohol_raw" not in payload:
        raise TelemetryError("Missing required vibration or alcohol_raw field")

    try:
        vibration = int(payload["vibration"])
        alcohol_raw = int(payload["alcohol_raw"])
    except (TypeError, ValueError) as exc:
        raise TelemetryError("Sensor values must be integers") from exc

    if vibration not in (0, 1):
        raise TelemetryError("vibration must be 0 or 1")
    if not 0 <= alcohol_raw <= 1023:
        raise TelemetryError("alcohol_raw must be between 0 and 1023")

    gps_valid = payload.get("gps_valid", False)
    if not isinstance(gps_valid, bool):
        raise TelemetryError("gps_valid must be a boolean")

    result: dict[str, Any] = {
        "vibration": vibration,
        "alcohol_raw": alcohol_raw,
        "gps_valid": gps_valid,
    }

    if gps_valid:
        try:
            latitude = float(payload["latitude"])
            longitude = float(payload["longitude"])
        except (KeyError, TypeError, ValueError) as exc:
            raise TelemetryError("Valid GPS data requires numeric latitude and longitude") from exc

        if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
            raise TelemetryError("GPS coordinates are outside valid ranges")

        result["latitude"] = latitude
        result["longitude"] = longitude

        if "gps_age_ms" in payload:
            try:
                result["gps_age_ms"] = max(0, int(payload["gps_age_ms"]))
            except (TypeError, ValueError) as exc:
                raise TelemetryError("gps_age_ms must be an integer") from exc

    return result


def format_location(data: dict[str, Any]) -> str:
    if not data.get("gps_valid"):
        return "GPS fix unavailable."

    lat = data["latitude"]
    lon = data["longitude"]
    maps_url = f"https://www.google.com/maps?q={lat:.6f},{lon:.6f}"
    age = data.get("gps_age_ms")
    age_line = f"\nGPS fix age: {age} ms" if age is not None else ""
    return (
        f"Latitude: {lat:.6f}\n"
        f"Longitude: {lon:.6f}{age_line}\n"
        f"Map: {maps_url}"
    )
