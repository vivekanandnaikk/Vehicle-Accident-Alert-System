"""Application configuration loaded from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Config:
    serial_port: str = "COM3"
    baud_rate: int = 9600
    alcohol_threshold: int = 500
    alert_cooldown_seconds: int = 60
    vibration_active_level: int = 1
    email_sender: str = ""
    email_app_password: str = ""
    email_recipient: str = ""
    dry_run: bool = True

    @classmethod
    def from_environment(cls) -> "Config":
        config = cls(
            serial_port=os.getenv("SERIAL_PORT", "COM3"),
            baud_rate=_int_env("BAUD_RATE", 9600),
            alcohol_threshold=_int_env("ALCOHOL_THRESHOLD", 500),
            alert_cooldown_seconds=_int_env("ALERT_COOLDOWN_SECONDS", 60),
            vibration_active_level=_int_env("VIBRATION_ACTIVE_LEVEL", 1),
            email_sender=os.getenv("EMAIL_SENDER", ""),
            email_app_password=os.getenv("EMAIL_APP_PASSWORD", ""),
            email_recipient=os.getenv("EMAIL_RECIPIENT", ""),
            dry_run=_bool_env("DRY_RUN", True),
        )
        if not 0 <= config.alcohol_threshold <= 1023:
            raise ValueError("ALCOHOL_THRESHOLD must be between 0 and 1023")
        if config.vibration_active_level not in (0, 1):
            raise ValueError("VIBRATION_ACTIVE_LEVEL must be 0 or 1")
        if config.baud_rate <= 0:
            raise ValueError("BAUD_RATE must be positive")
        if config.alert_cooldown_seconds < 0:
            raise ValueError("ALERT_COOLDOWN_SECONDS cannot be negative")
        return config
