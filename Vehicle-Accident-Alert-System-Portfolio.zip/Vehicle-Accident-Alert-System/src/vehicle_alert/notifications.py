"""Notification backends: console dry-run and Gmail SMTP."""

from __future__ import annotations

import smtplib
from email.message import EmailMessage

from .config import Config
from .events import AlertEvent


class Notifier:
    def send(self, event: AlertEvent) -> bool:
        raise NotImplementedError


class ConsoleNotifier(Notifier):
    def send(self, event: AlertEvent) -> bool:
        print("\n" + "=" * 68)
        print(f"DRY RUN — {event.subject}")
        print(event.body)
        print("=" * 68 + "\n")
        return True


class GmailNotifier(Notifier):
    def __init__(self, config: Config) -> None:
        missing = [
            name for name, value in (
                ("EMAIL_SENDER", config.email_sender),
                ("EMAIL_APP_PASSWORD", config.email_app_password),
                ("EMAIL_RECIPIENT", config.email_recipient),
            ) if not value
        ]
        if missing:
            raise ValueError("Missing email configuration: " + ", ".join(missing))
        self.config = config

    def send(self, event: AlertEvent) -> bool:
        message = EmailMessage()
        message["From"] = self.config.email_sender
        message["To"] = self.config.email_recipient
        message["Subject"] = event.subject
        message.set_content(event.body)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=20) as smtp:
            smtp.login(self.config.email_sender, self.config.email_app_password)
            smtp.send_message(message)
        return True
