"""Vehicle Accident Alert System Python package."""
