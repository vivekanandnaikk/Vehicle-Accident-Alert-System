"""Serial application entry point."""

from __future__ import annotations

import sys
import time

import serial
from dotenv import load_dotenv
from serial import SerialException

from .config import Config
from .events import EventDetector
from .notifications import ConsoleNotifier, GmailNotifier
from .protocol import TelemetryError, parse_telemetry


def main() -> int:
    load_dotenv()
    try:
        config = Config.from_environment()
    except ValueError as exc:
        print(f"[CONFIG] {exc}", file=sys.stderr)
        return 2

    detector = EventDetector(
        alcohol_threshold=config.alcohol_threshold,
        vibration_active_level=config.vibration_active_level,
        cooldown_seconds=config.alert_cooldown_seconds,
    )
    try:
        notifier = ConsoleNotifier() if config.dry_run else GmailNotifier(config)
    except ValueError as exc:
        print(f"[CONFIG] {exc}", file=sys.stderr)
        return 2

    print("Vehicle Accident Alert System — Python host")
    print(f"Serial port: {config.serial_port} @ {config.baud_rate} baud")
    print(f"Dry run: {config.dry_run}")
    print("Press Ctrl+C to stop.")

    try:
        with serial.Serial(config.serial_port, config.baud_rate, timeout=1) as port:
            # Arduino Uno commonly resets when its serial port is opened.
            time.sleep(2)
            while True:
                raw = port.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue

                try:
                    data = parse_telemetry(line)
                except TelemetryError as exc:
                    print(f"[SERIAL] Ignoring invalid telemetry: {exc}")
                    continue

                print(
                    f"[DATA] vibration={data['vibration']} "
                    f"MQ3={data['alcohol_raw']} "
                    f"GPS={'valid' if data['gps_valid'] else 'no fix'}"
                )
                for event in detector.evaluate(data, time.monotonic()):
                    try:
                        notifier.send(event)
                        print(f"[ALERT] Processed {event.kind} notification.")
                    except (OSError, smtplib_error_types()) as exc:
                        print(f"[ALERT] Notification failed: {exc}", file=sys.stderr)

    except KeyboardInterrupt:
        print("\nStopped by user.")
        return 0
    except SerialException as exc:
        print(f"[SERIAL] Could not use {config.serial_port}: {exc}", file=sys.stderr)
        return 1


def smtplib_error_types():
    # Keep SMTP exception handling explicit without exposing SMTP details elsewhere.
    import smtplib
    return smtplib.SMTPException


if __name__ == "__main__":
    raise SystemExit(main())
