"""Simple edge/threshold event logic for prototype sensor telemetry."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AlertEvent:
    kind: str
    subject: str
    body: str


class EventDetector:
    """Detect vibration active edges and MQ-3 threshold crossings.

    The vibration input is only a vibration trigger, not a verified crash.
    The MQ-3 value is a raw ADC count, not a calibrated alcohol measurement.
    """

    def __init__(
        self,
        alcohol_threshold: int,
        vibration_active_level: int = 1,
        cooldown_seconds: float = 60,
    ) -> None:
        self.alcohol_threshold = alcohol_threshold
        self.vibration_active_level = vibration_active_level
        self.cooldown_seconds = cooldown_seconds
        self._previous_vibration_active = False
        self._last_sent: dict[str, float] = {}

    def evaluate(self, data: dict[str, Any], now: float) -> list[AlertEvent]:
        events: list[AlertEvent] = []
        vibration_active = data["vibration"] == self.vibration_active_level
        location = _location_text(data)

        if vibration_active and not self._previous_vibration_active:
            if self._ready("vibration", now):
                events.append(
                    AlertEvent(
                        kind="vibration",
                        subject="Vehicle safety alert: vibration event detected",
                        body=(
                            "A vibration trigger was detected by the educational prototype.\n"
                            "This does not confirm that a vehicle collision occurred.\n\n"
                            f"Vibration input: {data['vibration']}\n"
                            f"MQ-3 raw ADC reading: {data['alcohol_raw']}\n\n"
                            f"Location:\n{location}"
                        ),
                    )
                )
                self._last_sent["vibration"] = now

        self._previous_vibration_active = vibration_active

        alcohol_active = data["alcohol_raw"] >= self.alcohol_threshold
        if alcohol_active and self._ready("alcohol", now):
            events.append(
                AlertEvent(
                    kind="alcohol",
                    subject="Vehicle safety warning: MQ-3 threshold exceeded",
                    body=(
                        "The MQ-3 raw sensor reading exceeded the configured prototype threshold.\n"
                        "This is not a calibrated alcohol concentration or an impairment assessment.\n\n"
                        f"MQ-3 raw ADC reading: {data['alcohol_raw']}\n"
                        f"Configured threshold: {self.alcohol_threshold}\n\n"
                        f"Location:\n{location}"
                    ),
                )
            )
            self._last_sent["alcohol"] = now

        return events

    def _ready(self, kind: str, now: float) -> bool:
        last = self._last_sent.get(kind)
        return last is None or now - last >= self.cooldown_seconds


def _location_text(data: dict[str, Any]) -> str:
    if not data.get("gps_valid"):
        return "GPS fix unavailable."
    lat = data["latitude"]
    lon = data["longitude"]
    return (
        f"Latitude: {lat:.6f}\n"
        f"Longitude: {lon:.6f}\n"
        f"Map: https://www.google.com/maps?q={lat:.6f},{lon:.6f}"
    )
