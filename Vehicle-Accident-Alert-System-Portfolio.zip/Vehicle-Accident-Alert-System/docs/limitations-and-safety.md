# Limitations and Safety

This project is an educational prototype only. It is not certified, validated, or suitable for real-world emergency response.

## Accident detection

A simple vibration module reports vibration or movement at its mounting point. It can trigger from road irregularities, engine vibration, handling, or impacts unrelated to a collision. It cannot reliably identify a vehicle crash, estimate severity, or determine whether occupants need assistance.

A production crash-detection system requires automotive-grade sensors, validated algorithms, redundancy, environmental qualification, and extensive safety testing.

## Alcohol sensing

The MQ-3 is a semiconductor gas sensor. Its analog output is affected by warm-up, temperature, humidity, airflow, sensor age, and calibration. A raw ADC threshold is not a breath-alcohol concentration, blood-alcohol concentration, or legal impairment determination. Do not use this prototype to judge whether anyone is safe or legally permitted to drive.

## GPS

GPS can be unavailable or inaccurate indoors, in tunnels, or near obstructions. A valid fix can still be stale or imprecise. This implementation includes the GPS fix age but does not enforce a maximum freshness limit.

## Notifications

The Python host requires a powered computer and internet access. Gmail SMTP and email networks can delay, reject, or fail to deliver messages. Email is not a guaranteed emergency communications channel.

## Safe use

Do not rely on this project instead of airbags, certified eCall systems, emergency services, certified alcohol interlocks, or other vehicle safety equipment. Perform controlled bench tests only.
