# Architecture and Design

## Design decision

The remembered parts list includes an Arduino Uno and Python. Since the Uno cannot execute Python natively, this reference architecture divides the work:

- **Arduino firmware:** sensor acquisition, GPS parsing, serial telemetry.
- **Python host:** telemetry validation, event detection, cooldowns, and email delivery.

This means the prototype needs a computer connected to the Arduino. It is not a standalone vehicle unit.

## Data path

```text
[Digital vibration module] --D2--\
[M Q-3 analog output] ------A0-----> [Arduino Uno]
[NEO-6M GPS UART] ----------D4/D3-/       |
                                             | USB serial, 9600 baud
                                             | newline-delimited JSON
                                             v
                                      [Python application]
                                        |            |
                                  Event detector   GPS link
                                        |
                                  Notification layer
                                        |
                                  [Gmail SMTP inbox]
```

## Why JSON Lines?

Each telemetry sample is sent as one compact JSON object terminated by a newline. This is easy to inspect in Serial Monitor, parse on the Python side, and extend with future sensor fields.

## Event logic

- Vibration: a transition into the configured active state creates one event. The detector does not repeatedly alert while the digital input remains active. A cooldown limits repeated triggers after the input returns inactive.
- MQ-3: a raw ADC reading at or above the configured threshold creates a warning, subject to a cooldown.
- GPS: if the GPS library has a valid location, coordinates and fix age are included. Otherwise, the alert explicitly reports that GPS is unavailable.

The thresholds and event rules are prototype choices, not validated crash or impairment algorithms.
