# Calibration and Bench Testing

Do not test this project on a moving vehicle or by staging a collision.

## A. Firmware/serial smoke test

1. Confirm wiring and common ground.
2. Flash the Arduino sketch.
3. Open Serial Monitor at 9600 baud.
4. Confirm one JSON line appears approximately every 500 ms.
5. Trigger the vibration module gently by hand and observe whether `vibration` changes.
6. Observe MQ-3 raw values after the sensor has warmed up.
7. Test GPS outdoors with a clear sky view; acquisition may take several minutes.
8. Close Serial Monitor before running the Python host.

## B. Python tests

From repository root:

```bash
python -m unittest discover -s tests -v
```

## C. End-to-end dry run

Set `DRY_RUN=true`, configure the serial port, then launch:

```bash
PYTHONPATH=src python -m vehicle_alert.app
```

On Windows PowerShell:

```powershell
$env:PYTHONPATH="src"
python -m vehicle_alert.app
```

The console notifier prints alert content without sending email.

## D. MQ-3 calibration notes

- Follow the specific sensor/module datasheet for initial burn-in and warm-up.
- Record the clean-air baseline in the intended environment.
- Observe repeatability across multiple readings.
- Select a prototype raw ADC threshold based on documented bench observations.
- Do not translate raw ADC counts into BAC or breath-alcohol concentration without a validated calibration method and appropriate instrumentation.

## E. Vibration sensor notes

- Confirm active HIGH/LOW behavior.
- Secure the module to a stable test fixture.
- Record normal background triggers and sensitivity-potentiometer settings, if present.
- A low-cost vibration switch is not a crash sensor and cannot determine crash severity.

## F. Email verification

Only after dry-run testing:
1. Configure a Gmail app password if supported by the account.
2. Use an email recipient you control for initial testing.
3. Set `DRY_RUN=false`.
4. Trigger a controlled bench event.
5. Verify message delivery and inspect spam/junk folders.

Do not send unverified prototype alerts to real emergency contacts.
