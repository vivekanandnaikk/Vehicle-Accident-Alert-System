# Serial Protocol

Transport: USB serial  
Baud rate: 9600  
Framing: UTF-8 JSON Lines (one JSON object followed by `\n`)

## Required fields

| Field | Type | Meaning |
|---|---|---|
| `vibration` | integer 0 or 1 | Normalized vibration-module state |
| `alcohol_raw` | integer 0–1023 | Arduino ADC raw count from MQ-3 analog output |
| `gps_valid` | boolean | Whether TinyGPSPlus reports a valid location |

## GPS fields

When `gps_valid` is `true`, the line also contains:

| Field | Type | Meaning |
|---|---|---|
| `latitude` | number | Decimal degrees, -90 to +90 |
| `longitude` | number | Decimal degrees, -180 to +180 |
| `gps_age_ms` | integer | Age of the last location update in milliseconds |

Example (illustrative coordinates only):

```json
{"vibration":0,"alcohol_raw":184,"gps_valid":true,"latitude":12.971600,"longitude":77.594600,"gps_age_ms":900}
```

When there is no valid fix:

```json
{"vibration":0,"alcohol_raw":184,"gps_valid":false}
```

The Python parser rejects malformed JSON, missing required fields, invalid sensor ranges, and invalid coordinates.
