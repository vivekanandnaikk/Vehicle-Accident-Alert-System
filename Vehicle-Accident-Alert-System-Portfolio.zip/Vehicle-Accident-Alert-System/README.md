# Vehicle Accident Alert System

[![Python tests](https://github.com/YOUR_USERNAME/Vehicle-Accident-Alert-System/actions/workflows/python-tests.yml/badge.svg)](https://github.com/YOUR_USERNAME/Vehicle-Accident-Alert-System/actions/workflows/python-tests.yml)
![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Arduino](https://img.shields.io/badge/Arduino-Uno-00979D)
![Status](https://img.shields.io/badge/status-educational%20prototype-orange)

An educational automotive-safety prototype that combines vibration-event monitoring, MQ-3 sensor readings, GPS coordinates, and Python-powered email notifications.

> **Important — reconstructed project:** The original source files and circuit records were unavailable. This repository is a clean reference implementation reconstructed from the author's recollection of the hardware: Arduino Uno, vibration sensor, MQ-3 alcohol sensor, NEO-6M GPS, and Python/Gmail SMTP. The exact original wiring, thresholds, sensor model, and program flow have not been independently verified. This code is a new implementation, not recovered original source code.

## Project summary

The Arduino Uno interfaces with the sensors and streams structured readings to a computer over USB serial. A Python application on that computer parses the readings, detects configured events, and can send email notifications through Gmail SMTP.

**The Arduino Uno does not run Python.** In this architecture, Arduino firmware performs hardware acquisition; Python runs on a connected host computer and handles event logic and notifications. The computer and internet connection are therefore required for email delivery.

## Features

- Reads a digital vibration-sensor output.
- Reads the MQ-3 module's analog output (raw ADC count).
- Parses NEO-6M GPS data using TinyGPSPlus.
- Sends newline-delimited JSON from Arduino to Python over USB serial.
- Detects vibration trigger edges and applies an alert cooldown.
- Monitors a configurable MQ-3 raw-value threshold with a cooldown.
- Includes the most recent valid GPS fix in email alerts.
- Supports dry-run mode for safe software testing without sending email.
- Includes unit tests for parsing, event detection, and location formatting.

## System architecture

```mermaid
flowchart LR
    V[Vibration sensor] --> A[Arduino Uno]
    M[MQ-3 analog output] --> A
    G[NEO-6M GPS] --> A
    A -->|USB serial / JSONL| P[Python host application]
    P --> E[Gmail SMTP]
    E --> R[Emergency contact inbox]
    P --> L[GPS coordinates / Maps link]
```

1. Arduino samples the vibration sensor and MQ-3 analog output.
2. TinyGPSPlus parses GPS NMEA data from the NEO-6M.
3. Arduino emits one JSON object per line over USB serial.
4. Python validates and parses each line.
5. Python detects a vibration trigger edge or an MQ-3 threshold crossing.
6. When configured, Python sends an email with sensor details and the latest valid GPS fix.

## Hardware

| Component | Role | Reference connection |
|---|---|---|
| Arduino Uno | Sensor interface and serial telemetry | USB to host computer |
| Digital vibration module | Vibration/impact trigger input | DO → D2 |
| MQ-3 module | Alcohol-sensitive analog reading | AO → A0 |
| NEO-6M GPS breakout | Latitude/longitude | TX → D4, RX → D3 |
| Computer | Runs Python application | USB serial |

The exact vibration-module model was not remembered. The example assumes a digital-output module such as an SW-420-style board. Confirm your actual board's pinout and output polarity before use.

### Wiring reference

| Module | Pin | Arduino Uno |
|---|---|---|
| Vibration module | DO | D2 |
| Vibration module | VCC / GND | Supply supported by module / GND |
| MQ-3 module | AO | A0 |
| MQ-3 module | VCC / GND | Supply supported by module / GND |
| NEO-6M | TX | D4 (SoftwareSerial RX) |
| NEO-6M | RX | D3 (SoftwareSerial TX; level compatibility must be checked) |
| NEO-6M | GND | GND |
| NEO-6M | VCC | As specified for the particular breakout |

**Electrical precautions**
- Connect grounds together.
- Do not assume every NEO-6M breakout accepts 5 V on VCC or 5 V UART logic. Check its regulator and logic-level specifications; use level shifting where required.
- MQ-3 modules contain a heater and can draw appreciable current. Use a suitable supply and allow warm-up as required by the sensor documentation.
- The sketch defaults to an active-HIGH vibration output. Change `VIBRATION_ACTIVE_LEVEL` if your module is active LOW.
- Do not power the complete assembly from an unsuitable source.

## Repository layout

```text
Vehicle-Accident-Alert-System/
├── .github/workflows/python-tests.yml
├── .gitignore
├── .env.example
├── LICENSE
├── README.md
├── requirements.txt
├── arduino/
│   └── vehicle_accident_alert.ino
├── docs/
│   ├── architecture.md
│   ├── calibration-and-testing.md
│   ├── limitations-and-safety.md
│   └── serial-protocol.md
├── examples/
│   └── sample_telemetry.jsonl
├── hardware/
│   └── wiring.md
├── src/
│   └── vehicle_alert/
│       ├── __init__.py
│       ├── app.py
│       ├── config.py
│       ├── events.py
│       ├── notifications.py
│       └── protocol.py
└── tests/
    ├── test_events.py
    └── test_protocol.py
```

## Software prerequisites

- Arduino IDE 2.x (or compatible Arduino IDE)
- Arduino Uno
- Python 3.10+
- USB data cable
- TinyGPSPlus Arduino library
- Python packages in `requirements.txt`
- Gmail account configured for SMTP app-password authentication, if using email alerts

## 1. Flash the Arduino

1. Install **TinyGPSPlus** using Arduino IDE Library Manager.
2. Open `arduino/vehicle_accident_alert.ino`.
3. Select **Arduino Uno** and the correct port.
4. Check the pin assignments against your actual modules.
5. Upload the sketch.
6. Open Serial Monitor at **9600 baud** and verify newline-delimited JSON appears.
7. Close Serial Monitor before starting Python; the serial port generally cannot be shared by both programs.

## 2. Install the Python application

From the repository root:

```bash
python -m venv .venv
```

Activate it:

```powershell
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

```bash
# macOS / Linux
source .venv/bin/activate
```

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

## 3. Configure the application

Copy `.env.example` to `.env` and fill in the values. The application loads `.env` automatically if `python-dotenv` is installed (it is included in `requirements.txt`).

```dotenv
SERIAL_PORT=COM3
BAUD_RATE=9600
ALCOHOL_THRESHOLD=500
ALERT_COOLDOWN_SECONDS=60
VIBRATION_ACTIVE_LEVEL=1

EMAIL_SENDER=youraddress@gmail.com
EMAIL_APP_PASSWORD=your_google_app_password
EMAIL_RECIPIENT=emergencycontact@example.com

DRY_RUN=true
```

On Linux, the serial port may look like `/dev/ttyACM0` or `/dev/ttyUSB0`. On macOS, it may look like `/dev/cu.usbmodem...`.

For Gmail, use an app password where your Google account supports it. Never use your normal account password in this project. Never commit `.env`.

## 4. Run in safe dry-run mode

Keep `DRY_RUN=true` initially. This prints notifications rather than sending them.

```bash
python -m vehicle_alert.app
```

If running from the repository root, set the package path:

```powershell
# Windows PowerShell
$env:PYTHONPATH="src"
python -m vehicle_alert.app
```

```bash
# macOS / Linux
export PYTHONPATH=src
python -m vehicle_alert.app
```

After confirming the hardware and test recipient, set `DRY_RUN=false` to enable SMTP delivery.

## Configuration reference

| Variable | Description | Default |
|---|---|---|
| `SERIAL_PORT` | Arduino serial port | `COM3` |
| `BAUD_RATE` | Serial baud rate | `9600` |
| `ALCOHOL_THRESHOLD` | MQ-3 raw ADC threshold, 0–1023 | `500` |
| `ALERT_COOLDOWN_SECONDS` | Minimum repeat interval per alert type | `60` |
| `VIBRATION_ACTIVE_LEVEL` | Active digital level, `0` or `1` | `1` |
| `EMAIL_SENDER` | Gmail sender address | unset |
| `EMAIL_APP_PASSWORD` | Gmail app password | unset |
| `EMAIL_RECIPIENT` | Notification recipient | unset |
| `DRY_RUN` | Print alerts instead of sending | `true` |

The MQ-3 threshold is a **raw ADC count**, not a calibrated alcohol concentration, breath-alcohol result, or legal impairment measurement. The default value is only a placeholder; calibrate for the specific sensor and environment.

## Serial protocol

The firmware emits one JSON object followed by a newline, for example:

```json
{"vibration":1,"alcohol_raw":215,"gps_valid":true,"latitude":12.971600,"longitude":77.594600,"gps_age_ms":1200}
```

The coordinates are illustrative. See [`docs/serial-protocol.md`](docs/serial-protocol.md).

## Run tests

```bash
python -m unittest discover -s tests -v
```

Tests do not require Arduino hardware, a GPS fix, or Gmail credentials.

## Troubleshooting

| Symptom | Checks |
|---|---|
| Python cannot open serial port | Correct `SERIAL_PORT`; close Serial Monitor; check USB cable and OS permissions |
| No GPS fix | Test outdoors; wait for satellite acquisition; check GPS TX/RX cross-connection and baud rate |
| Vibration alerts never trigger | Check DO pin, common ground, output polarity, and `VIBRATION_ACTIVE_LEVEL` |
| Too many vibration alerts | Adjust module sensitivity, inspect mounting, and tune cooldown; do not treat vibration as confirmed crash |
| MQ-3 value seems unstable | Allow warm-up, check supply, airflow, analog wiring, and sensor calibration |
| Email not delivered | Check SMTP settings, app password, recipient, internet, and Google account security settings |

## Known limitations and safety

This is a learning prototype, not a production or certified vehicle safety system.

- A vibration switch/module detects vibration, not a confirmed collision. Road bumps, engine vibration, handling, and mounting can cause false triggers.
- A single digital vibration input cannot estimate crash severity or distinguish crash types.
- MQ-3 raw readings are sensitive to warm-up, temperature, humidity, airflow, sensor age, and calibration. They must not be used to determine whether someone is legally intoxicated or fit to drive.
- GPS may be unavailable, delayed, or inaccurate indoors or in obstructed environments.
- The Python host computer and an internet connection are required for SMTP notifications.
- Email delivery is not guaranteed to be immediate or reliable enough for emergency response.
- Do not use this project as a replacement for airbags, eCall, certified alcohol interlocks, emergency services, or other safety equipment.
- Test on a bench, never by staging a road collision or driving while impaired.

See [`docs/limitations-and-safety.md`](docs/limitations-and-safety.md).

## Future work

- Add a dedicated cellular communication module for host-independent notifications.
- Replace the vibration switch with an automotive-grade IMU and validated crash-detection logic.
- Add sensor self-tests, watchdog recovery, and power-failure handling.
- Add GPS age/freshness checks and store event timestamps.
- Add a cancel/countdown flow to reduce false alerts.
- Validate the design through controlled bench testing and documented test results.

## Author

**Vicky Naik**  
Electronics and Communication Engineering Graduate

---

If you build or test this reference implementation, update the repository with your verified module model numbers, photos, measured thresholds, wiring, and test results. Do not claim performance figures until you have measured them.
