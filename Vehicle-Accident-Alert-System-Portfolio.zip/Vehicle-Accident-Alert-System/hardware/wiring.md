# Hardware Wiring Reference

Verify the exact breakout-board documentation before connecting power or signal pins.

| Module | Pin | Arduino Uno pin |
|---|---|---|
| Vibration module | DO | D2 |
| Vibration module | VCC | Module-rated supply |
| Vibration module | GND | GND |
| MQ-3 module | AO | A0 |
| MQ-3 module | VCC | Module-rated supply |
| MQ-3 module | GND | GND |
| NEO-6M | TX | D4 |
| NEO-6M | RX | D3 (check logic-level compatibility) |
| NEO-6M | GND | GND |
| NEO-6M | VCC | Breakout-board rated supply |

## Notes

- SoftwareSerial is configured with Arduino D4 as RX and D3 as TX.
- GPS TX connects to Arduino RX (D4); GPS RX connects to Arduino TX (D3).
- The Arduino USB serial connection to Python uses the Uno's hardware serial port.
- Connect all grounds.
- Confirm vibration digital-output polarity. Firmware currently normalizes active HIGH to `1`.
- Check the GPS breakout's input regulator and UART logic levels; do not assume 5 V tolerance.
- MQ-3 heater power requirements can exceed what is appropriate for a weak supply.
