/*
 * Vehicle Accident Alert System — Arduino Uno sensor interface
 *
 * Reconstructed reference firmware; verify all module pinouts and logic levels.
 *
 * Vibration module DO -> D2 (active HIGH by default)
 * MQ-3 module AO      -> A0
 * NEO-6M GPS TX       -> D4 (Arduino SoftwareSerial RX)
 * NEO-6M GPS RX       -> D3 (Arduino SoftwareSerial TX; check logic levels)
 * USB serial to host  -> 9600 baud
 *
 * Install TinyGPSPlus from Arduino Library Manager.
 * Arduino acquires sensor data and emits JSONL. Python runs on the connected
 * computer and handles event logic/email; Python does not run on the Uno.
 */

#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>

const uint8_t VIBRATION_PIN = 2;
const uint8_t ALCOHOL_PIN = A0;
const uint8_t GPS_RX_PIN = 4;
const uint8_t GPS_TX_PIN = 3;
const unsigned long TELEMETRY_INTERVAL_MS = 500;
const int VIBRATION_ACTIVE_LEVEL = HIGH; // Change to LOW if required by module.

SoftwareSerial gpsSerial(GPS_RX_PIN, GPS_TX_PIN);
TinyGPSPlus gps;
unsigned long lastTelemetryMs = 0;

void setup() {
  pinMode(VIBRATION_PIN, INPUT);
  Serial.begin(9600);
  gpsSerial.begin(9600);
}

void loop() {
  while (gpsSerial.available() > 0) {
    gps.encode(gpsSerial.read());
  }

  const unsigned long now = millis();
  if (now - lastTelemetryMs < TELEMETRY_INTERVAL_MS) {
    return;
  }
  lastTelemetryMs = now;

  const int vibrationRaw = digitalRead(VIBRATION_PIN);
  const int vibrationActive = (vibrationRaw == VIBRATION_ACTIVE_LEVEL) ? 1 : 0;
  const int alcoholRaw = analogRead(ALCOHOL_PIN);
  const bool gpsValid = gps.location.isValid();

  Serial.print("{\"vibration\":");
  Serial.print(vibrationActive);
  Serial.print(",\"alcohol_raw\":");
  Serial.print(alcoholRaw);
  Serial.print(",\"gps_valid\":");
  Serial.print(gpsValid ? "true" : "false");

  if (gpsValid) {
    Serial.print(",\"latitude\":");
    Serial.print(gps.location.lat(), 6);
    Serial.print(",\"longitude\":");
    Serial.print(gps.location.lng(), 6);
    Serial.print(",\"gps_age_ms\":");
    Serial.print(gps.location.age());
  }

  Serial.println("}");
}
